# ServerMaster — TODO

Everything that is planned but not built yet, plus the honest limits of what
ships today. Format: `[ ]` not started, `[~]` partially there.

---

## Features to build

### [ ] Localization — German, French, Danish, Japanese

English is the source language: the strings are written in English directly in
the Swift code, so English needs no `.lproj` of its own. Four languages are
still missing, and no others are planned.

Scope: about 733 keys per language, roughly 2900 translations in total.

How it is wired:

| Piece | Path |
|---|---|
| Language registry | `ServerMaster/Core/AppLanguage.swift` |
| One file per language | `ServerMaster/<code>.lproj/Localizable.strings` |

The translation key is the English text from the code. To add a language:
append an entry to `AppLanguage.supported`, drop the `.strings` file in place,
and add the code to `knownRegions` in `project.pbxproj`.

### [ ] Apache as an engine

Eight engines ship today (http-server, Node.js script, Python http.server, PHP
built-in, Nginx, Nginx + PHP-FPM, Caddy, custom command). Apache is not one of
them. The one thing it adds over Nginx is `.htaccess` support — which matters
for anyone arriving from XAMPP or MAMP with a project that already relies on it.

Work involved: an `ServerEngine.apache` case, a generated `httpd.conf` in
`ConfigTemplates`, `mod_php` or PHP-FPM wiring, and a Homebrew `httpd` check in
`DependencyChecker`.

### [ ] Intel support

Verified, not assumed: the app builds **arm64 only** today, in Debug *and* in
Release. `ARCHS` resolves to `arm64`, and the deployment target is macOS 27.0.
The About screen must not claim Intel support until this is real.

Work involved: build universal (`arm64` + `x86_64`), lower the deployment
target to a macOS version that actually runs on Intel, and replace whatever
APIs that forces us to give up. Then test on real Intel hardware — a universal
binary that has never been run on Intel is a guess, not support.

### [~] Database work without the command line

Already there: browse tables, edit cells in place, add and delete rows, run raw
SQL, copy results as CSV, create and drop databases.

Still missing: schema editing through the UI — create and alter tables, add,
rename and drop columns, indexes and keys, import and export `.sql` dumps, and
manage users and privileges. Right now those still need a terminal.

### [ ] Web database admin panel

Ship a one-click way to open a browser admin panel — Adminer (a single PHP
file, trivial to drop in) or phpMyAdmin — pointed at the profile's MariaDB
instance, without the user installing or configuring anything.

### [ ] Command line tool and its installer

A `servermaster` command for the terminal, so a profile can be started, stopped
and inspected without touching the window — useful in scripts, in a Makefile, or
over SSH.

Sketch of the surface: `servermaster start <profile>`, `stop`, `restart`,
`status`, `list`, `logs <profile>`, `ports`.

It needs an installer too, because a binary inside the `.app` bundle is not on
anyone's `PATH`. A button in Settings that symlinks the tool into
`/usr/local/bin` (with the system password prompt when that directory is not
writable), plus the matching uninstall. The Settings row should show whether the
tool is currently installed and which version it points at.

### [ ] Interface modes — Standard and Advanced

One setting that changes how much the app shows.

*Standard* is for someone who just needs a directory served on a port: pick a
folder, press Start. Ports, engines, config files and certificates stay out of
the way behind sensible defaults.

*Advanced* is what exists today: every engine option, config file editing,
sidecars, privileged ports, database tooling.

---

## Open issues

### [ ] Release builds are not signed for distribution

The app already points people at `mac/<version>` to download a new build, but a
build made today cannot be opened by anyone else. Verified: the archive signs
with *Apple Development*, and `spctl` rejects the result — on another Mac
Gatekeeper refuses to launch it.

Only an *Apple Development* certificate is installed. Distribution needs a
**Developer ID Application** certificate (Apple Developer Program, team
`88M5SYPGUR`), after which the release flow becomes:

```
xcodebuild archive -scheme ServerMaster -configuration Release \
    -destination 'generic/platform=macOS' -archivePath build/ServerMaster.xcarchive
xcodebuild -exportArchive -archivePath build/ServerMaster.xcarchive \
    -exportOptionsPlist ExportOptions.plist -exportPath build/export
xcrun notarytool submit build/export/ServerMaster.zip --keychain-profile AC --wait
xcrun stapler staple build/export/ServerMaster.app
```

with `method` set to `developer-id` in `ExportOptions.plist`. Until then, anyone
downloading a build has to strip the quarantine flag by hand, which is a poor
first impression for the exact beginner this tool is aimed at.

### [ ] Several sections have never been looked at

Confirmed working by the user: **Control**, **Profiles**, and starting on port
443.

Never opened and clicked by anyone: **Console**, **Database**, **Ports**,
**Dependencies**, **Settings**, the certificates window, the config editor, and
the shutdown window. They pass their tests, but tests are not eyes.

### [ ] Self-signed certificate is not marked as trusted

A deliberate choice, not a breakage. Checked on the user's machine: the
certificate is issued as `CN=localhost, O=ServerMaster` — so openssl, not
mkcert. HTTPS works and the encryption is real, but `security verify-cert`
returns `CSSMERR_TP_NOT_TRUSTED`, so the browser shows a warning that has to be
clicked through by hand.

Two ways to remove the warning, both requiring a password:

- **Certificates…** → *Trust in the system* for the current certificate, or
- switch to mkcert and install its local CA.

Either is fine, and so is leaving it as is.

### [ ] The test suites depend on fixtures that live outside the repository

Two suites need scaffolding that is not version controlled, so a fresh checkout
cannot run them as they are:

- The Joomla suite installs Joomla from scratch out of `pristine5` / `pristine6`
  in the scratchpad. Delete those folders and it stops passing.
- The update-checker suite expects a static HTTP server on `127.0.0.1:19000`
  serving the mock `raw` and `api` trees. Without it all nine network checks
  fail with *Could not connect to the server* — which looks like a code
  regression and is not one.

This is test infrastructure, not application code, but it should either move
into the repository or be started automatically by the suites themselves.

---

## Tool limitations — not app bugs

**http-server does not protect dotfiles.** Its `--no-dotfiles` flag only hides
them from the directory listing; a direct request for `/.env` still returns the
contents. Verified live. Only Nginx and Caddy actually deny access. The UI says
so plainly, so the checkbox does not create false confidence.

**Custom error pages work only on Nginx and Caddy.** http-server, Python and the
PHP built-in server cannot do it at all. The switch is disabled for them, with
the reason shown.

**Ports below 1024 require uid 0.** Being in the `admin` group is not enough —
it has to be root. Handled by launching through the system password prompt (see
*Administrator rights* in the profile). The password is typed into a macOS
window; the app never sees it.
